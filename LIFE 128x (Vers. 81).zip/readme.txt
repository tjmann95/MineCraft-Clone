FOREWORD:'LIFE' Texture Pack is licensed under a Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License.


My textures (those not mentioned in the 'credits' section below) may not be remixed and distributed without my consent. Please message me (StormCoreFilms) via the MineCraft forums or through Planet Minecraft.

All pictures and textures used are copyright of their respective owners.


CREDITS:

Uses HD font by d3fin3d: http://www.minecraftforum.net/topic/834569-64x-32x-hd-minecraft-font-default-style/